//
//  main.cpp
//  BinaryTree
//
//  Created by Roman on 6/3/17.
//  Copyright © 2017 Roma. All rights reserved.
//

#include <iostream>
#include "BT.hpp"
//короч мейн тут викликаю функції адд додаю елемент в дерево пошуку функція show буде виводити дерево вона ще не зовсім готова типу виводить але не дуже красиво. Потім буде краще
int main(int argc, const char * argv[]) {
    BT tree;
    tree.Add(8);
    tree.Add(4);
    tree.Add(1);
    tree.Add(5);
    tree.Add(6);
    tree.Add(7);
    tree.Add(9);
    tree.Add(10);
   
    
    tree.Show(tree.getHead());
    
}
