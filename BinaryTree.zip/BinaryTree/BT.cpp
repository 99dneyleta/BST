//
//  BT.cpp
//  BinaryTree
//
//  Created by Roman on 6/3/17.
//  Copyright © 2017 Roma. All rights reserved.
//

#include "BT.hpp"
#include <list>

BTNode* BT::getHead() {
    return this->_head;
}

//рекурсивна функція додавання
//Основна ідея:
//ти короч такий береш елемент дивишся на його знач якщо це знач менше ніж ти хочеш додати йдеш направо дивишся якщо справа значення менше знову йдеш направо і тд поки не побачиш нуль куди можна вставити(почитай про додавання у бінарне дерево)
void AddTo(BTNode *node, int value) {
    if(value < node->Value) {
        if(node->Left == NULL) {
            node->Left = new BTNode(value);
        }
        else {
            AddTo(node->Left, value);
        }
    }
    else {
        if(node->Right == NULL) {
            node->Right = new BTNode(value);
        }
        else {
            AddTo(node->Right, value);
        }
    }
    
}


// ну це функція головна я дивлюсь якщо список не порожній то викликаю верхню функцію інакше вставляю в голову ну і потім збільшую розмір
void BT::Add(int value) {
    if(_head == NULL) {
        _head = new BTNode(value);
    }
    else {
        AddTo(_head,value);
        
    }
    _count++;
}

//функція видалення(ітеративна) майже працює там трішки дописати залишилось
/*bool BT::Remove(int value) {
    BTNode *curr = nullptr, *parent = nullptr;
    curr = FindWithParent(value, "node", this->_head);
    parent = FindWithParent(value, "parent", this->_head);
    if(curr == NULL) {
        return false;
    }
    
    _count--;
    
    if(curr->Left == NULL && curr->Right == NULL) {
        if(parent->Left == curr)
            parent->Left = NULL;
        else
            parent->Right = NULL;
        curr = NULL;
    }
    
    else if(curr->Left == NULL || curr->Right == NULL) {
        if(curr->Right != NULL) {
            if(parent->Right == curr)
                parent->Right = curr->Right;
            else
                parent->Left = curr->Right;
            curr = NULL;

        }
        else {
            if(parent->Right == curr)
                parent->Right = curr->Left;
            else
                parent->Left = curr->Left;
            curr = NULL;
          
        }
    }
    
    else if(curr->Left != NULL && curr->Right != NULL) {
        
    }
    return true;
}
 */

// функція знайдення мінімального знач у дереві
BTNode Min(BTNode * root) {
    if(root->Left != NULL)
        return Min(root->Left);
    else
        return *root;
}

//функція видалення рекурсивна розглядається 3 випадки коли елемент який потрібно видалити не має дітей або має хоча б 1 або має двох (раджу також почитати)
BTNode* BT::Remove(int value, BTNode *root) {
    if (root == NULL)
        return root;
    if(value < root->Value)
        root->Left = Remove(value, root->Left);
    else if (value > root->Value)
        root->Right = Remove(value, root->Right);
    else if (root->Left != NULL && root->Right != NULL) {
        root->Value = Min(root->Right).Value;
        root->Right = Remove(root->Value, root->Right);
    }
    else {
        if(root->Left != NULL)
            root = root->Left;
        else
            root = root->Right;
    }
    
    return root;
}




//функція яка знаходить елемент і повертає його або повертає батька в залежності того що ти передаш стрінгом ("parent"-поверне батька "node"-поверне його)

BTNode* BT::FindWithParent(int value, std::string str, BTNode *node) {
    BTNode *k = new BTNode(-1);
    if(node->Value == value) {
        k = node;
    }
    
    if(node->Left != NULL){
        if(value == node->Left->Value) {// || (value == node->Right->Value)) {
        if(str == "parent")
            k = node;
        else {
            if(value == node->Left->Value)
                k = node->Left;
            else k = node->Right;
        }
    }
        else {
            if(node->Left != NULL && k->Value == -1) {
                k = FindWithParent(value, str, node->Left);
            }
        }
    }
    if(node->Right != NULL ) {
        if(value == node->Right->Value) {
            if(str == "parent") {
                k =  node;
            }
            else {
                if(value == node->Left->Value)
                    k = node->Left;
                else k = node->Right;
            }
        }
        
    else {
        if(node->Right != NULL && k->Value == -1) {
                k = FindWithParent(value, str, node->Right);
        }
    }
    }
    
    return k;
}


// ну і фунція показу працює навіть виводить правда поки не дуже красиво. суть в тому що я проходжу дерево по рівнях при цьому використовую стек і потім виводжу (алгоритм досить цікавий хоч теж почитай)
void BT::Show(BTNode *node){
    std::list<BTNode*> lvls;
    BTNode *curr = node;
    int currlvl = 0;
    int nxtlvl = 0;
    std::string lvlsnumbs, lvllink;
    std::cout<<"  ";
        int flag = 1;
    do{
        
        if(!lvls.empty()){
            
            curr = *lvls.begin();
            lvls.pop_front();
            currlvl-=1;
        }
        if(curr!= NULL)
            lvlsnumbs += std::to_string(curr->Value) + "    ";
        if(curr->Left != NULL){
        lvls.push_back(curr->Left);
            nxtlvl+=1;
            lvllink+="  /";
        }
        if(curr->Right !=NULL) {
        lvls.push_back(curr->Right);
            lvllink+="  |";
            nxtlvl+=1;
        }
        if(currlvl == 0){
            currlvl = nxtlvl;
            nxtlvl = 0;
            lvlsnumbs += '\n';
            lvllink += '\n';
            
        }

        
        curr = NULL;
        
        
    }while (!lvls.empty() || curr != NULL);
    std::cout<<lvlsnumbs;
    std::cout<<lvllink;
    
}


