//
//  BT.hpp
//  BinaryTree
//
//  Created by Roman on 6/3/17.
//  Copyright © 2017 Roma. All rights reserved.
//

#ifndef BT_hpp
#define BT_hpp

#include <stdio.h>
#include <iostream>
#include "BTNode.hpp"
//твій основний клас  містить в собі вказівник на початок дерева(голова) типу елемента ну і кількість всіх елементів. І функції реалізовані ще не всі, але все ж таки будуть ось такі

class BT {
private:
    BTNode *_head;
    int _count;
public:
    BT(){ // конструктор
        this->_head = NULL;
        this->_count = NULL;
    }
    
    void Add(int value); // додавання елементу в дерево
    bool Contains(int value); // чи дерево містить таке значення
    BTNode* Remove(int value,BTNode*); // видалення елементу зі списку
    BTNode* FindWithParent(int value, std::string node, BTNode *); //короч сложна функція повертає елемент або його батька в залежності що попросиш
    void Preorder(BTNode node); // цього ще немає короч обхід дерева почитай про них
    void PostOrder(BTNode node); // теж обхід
    void InOrder(BTNode node); // і ще один обхід
    void Clear(); //очищення дерева
    int getCount(); //отримання розміру
    BTNode* getHead();
    void Show(BTNode*); // функція виводу дерева

};

#endif /* BT_hpp */
